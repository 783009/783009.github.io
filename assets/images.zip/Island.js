(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Island_atlas_1", frames: [[0,1080,1449,492],[0,0,1920,1078],[1451,1080,555,554]]},
		{name:"Island_atlas_2", frames: [[830,285,533,203],[830,0,440,283],[1272,0,440,283],[1365,285,533,192],[0,0,466,592],[1714,0,313,200],[468,0,360,360]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Island_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Island_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Island_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Island_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(img.CachedBmp_9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,140);


(lib.CachedBmp_8 = function() {
	this.initialize(img.CachedBmp_8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,192);


(lib.CachedBmp_7 = function() {
	this.initialize(img.CachedBmp_7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,192);


(lib.CachedBmp_6 = function() {
	this.initialize(img.CachedBmp_6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,192);


(lib.CachedBmp_5 = function() {
	this.initialize(img.CachedBmp_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,192);


(lib.CachedBmp_4 = function() {
	this.initialize(img.CachedBmp_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,192);


(lib.CachedBmp_3 = function() {
	this.initialize(img.CachedBmp_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,192);


(lib.CachedBmp_2 = function() {
	this.initialize(img.CachedBmp_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2450,420);


(lib.CachedBmp_1 = function() {
	this.initialize(ss["Island_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.clipartboatpng3 = function() {
	this.initialize(img.clipartboatpng3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2371,1370);


(lib.cyberscootyfoinclipartxl = function() {
	this.initialize(ss["Island_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.download7 = function() {
	this.initialize(ss["Island_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.oceanlandscapebackgroundfreevector = function() {
	this.initialize(ss["Island_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Palm_Island_PNG_Clip_Art_Image596873376 = function() {
	this.initialize(img.Palm_Island_PNG_Clip_Art_Image596873376);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,8000,6446);


(lib.pngtreeyoungmancharacterpngimage_6485017 = function() {
	this.initialize(ss["Island_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.sheeppng26 = function() {
	this.initialize(ss["Island_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.wolf = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.download7();
	this.instance.setTransform(141.8,0,0.3043,0.3043,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,141.8,180.1);


(lib.ManGoingWithWolf = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.download7();
	this.instance.setTransform(0,57,0.3043,0.3043);

	this.instance_1 = new lib.pngtreeyoungmancharacterpngimage_6485017();
	this.instance_1.setTransform(96,0,0.6591,0.6591);

	this.instance_2 = new lib.clipartboatpng3();
	this.instance_2.setTransform(268.55,154,0.1082,0.1082,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,333.3,302.3);


(lib.ManGoingWithHay = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cyberscootyfoinclipartxl();
	this.instance.setTransform(0,172.6,0.0785,0.0785,-29.995);

	this.instance_1 = new lib.pngtreeyoungmancharacterpngimage_6485017();
	this.instance_1.setTransform(114.1,0,0.6591,0.6591);

	this.instance_2 = new lib.clipartboatpng3();
	this.instance_2.setTransform(286.65,154,0.1082,0.1082,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,351.4,302.3);


(lib.ManGoingBackWithSheep = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pngtreeyoungmancharacterpngimage_6485017();
	this.instance.setTransform(237.25,0,0.6591,0.6591,0,0,180);

	this.instance_1 = new lib.clipartboatpng3();
	this.instance_1.setTransform(65,154,0.1082,0.1082);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,321.6,302.3);


(lib.ManGoingBack = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pngtreeyoungmancharacterpngimage_6485017();
	this.instance.setTransform(237.25,0,0.6591,0.6591,0,0,180);

	this.instance_1 = new lib.clipartboatpng3();
	this.instance_1.setTransform(65,154,0.1082,0.1082);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,321.6,302.3);


(lib.btnSheep = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.sheeppng26();
	this.instance.setTransform(0,0,0.2806,0.2806);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,155.8,155.5);


(lib.btnPlay = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_13();
	this.instance.setTransform(473.5,236.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},4).wait(1));

	// Button
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape.setTransform(560.95,284.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00CC00").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_1.setTransform(560.95,284.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009900").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_2.setTransform(560.95,284.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape_3.setTransform(560.95,284.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_2},{t:this.shape_3}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,740,347.5);


(lib.btnNext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_12();
	this.instance.setTransform(458,220.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},4).wait(1));

	// Button
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape.setTransform(560.95,284.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00CC00").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_1.setTransform(560.95,284.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009900").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_2.setTransform(560.95,284.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape_3.setTransform(560.95,284.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_2},{t:this.shape_3}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,686.5,362.3);


(lib.btnHome = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_11();
	this.instance.setTransform(450.3,218.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},4).wait(1));

	// Button
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape.setTransform(560.95,284.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00CC00").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_1.setTransform(560.95,284.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009900").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_2.setTransform(560.95,284.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape_3.setTransform(560.95,284.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_2},{t:this.shape_3}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,686.5,360.1);


(lib.btnAnswer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(461.5,240.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},4).wait(1));

	// Button
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape.setTransform(560.95,284.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00CC00").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_1.setTransform(560.95,284.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009900").s().p("AyHIXIAAwtMAkPAAAIAAQtg");
	this.shape_2.setTransform(560.95,284.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(19,1,1).p("AyHoWMAkPAAAIAAQtMgkPAAAg");
	this.shape_3.setTransform(560.95,284.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_2},{t:this.shape_3}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,347.5);


(lib.ManGoingWithSheep = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pngtreeyoungmancharacterpngimage_6485017();
	this.instance.setTransform(-76.6,-151.1,0.6591,0.6591);

	this.Sheep_1 = new lib.btnSheep();
	this.Sheep_1.name = "Sheep_1";
	this.Sheep_1.setTransform(-71,6.05,1,1,0,0,0,77.9,77.7);

	this.instance_1 = new lib.clipartboatpng3();
	this.instance_1.setTransform(95.95,2.9,0.1082,0.1082,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.Sheep_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160.6,-151.1,321.29999999999995,302.29999999999995);


(lib.ManGoingBackWithSheep1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.Sheep_1 = new lib.btnSheep();
	this.Sheep_1.name = "Sheep_1";
	this.Sheep_1.setTransform(243.65,160.05,1,1,0,0,180,77.9,77.7);

	this.instance = new lib.ManGoingBackWithSheep("synched",0);
	this.instance.setTransform(160.8,151.1,1,1,0,0,0,160.8,151.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.Sheep_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,321.6,302.3);


// stage content:
(lib.Island = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {Welcome:0,Question:9,Answer:19};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,9,29,49,58,69,89];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Play_1.on('click', function(){
		/*
		Moves the playhead to the specified frame label in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndStop('Question');
		});
	}
	this.frame_9 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Answer_1.on('click', function(){
		/*
		Moves the playhead to the specified frame label in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay('Answer');
		});
	}
	this.frame_29 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		var _this = this;
		/*
		Get the frame number of current frame
		*/
		var frameNumber = _this.currentFrame;
		
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Next_1.on('click', function(){
		/*
		Moves the playhead to the specified frame number in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay(frameNumber + 1);
		});
	}
	this.frame_49 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		var _this = this;
		/*
		Get the frame number of current frame
		*/
		var frameNumber = _this.currentFrame;
		
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Next_1.on('click', function(){
		/*
		Moves the playhead to the specified frame number in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay(frameNumber + 1);
		});
	}
	this.frame_58 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		var _this = this;
		/*
		Get the frame number of current frame
		*/
		var frameNumber = _this.currentFrame;
		
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Next_1.on('click', function(){
		/*
		Moves the playhead to the specified frame number in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay(frameNumber + 1);
		});
	}
	this.frame_69 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		var _this = this;
		/*
		Get the frame number of current frame
		*/
		var frameNumber = _this.currentFrame;
		
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Next_1.on('click', function(){
		/*
		Moves the playhead to the specified frame number in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay(frameNumber + 1);
		});
	}
	this.frame_89 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.Home_1.on('click', function(){
		/*
		Moves the playhead to the specified frame label in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndStop('Welcome');
		});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(20).call(this.frame_29).wait(20).call(this.frame_49).wait(9).call(this.frame_58).wait(11).call(this.frame_69).wait(20).call(this.frame_89).wait(1));

	// Buttons
	this.Play_1 = new lib.btnPlay();
	this.Play_1.name = "Play_1";
	this.Play_1.setTransform(217.05,113.25,1,1,0,0,0,116,53.5);
	new cjs.ButtonHelper(this.Play_1, 0, 1, 2, false, new lib.btnPlay(), 3);

	this.Answer_1 = new lib.btnAnswer();
	this.Answer_1.name = "Answer_1";
	this.Answer_1.setTransform(101.05,60.05);
	new cjs.ButtonHelper(this.Answer_1, 0, 1, 2, false, new lib.btnAnswer(), 3);

	this.Next_1 = new lib.btnNext();
	this.Next_1.name = "Next_1";
	this.Next_1.setTransform(100.55,60.05);
	new cjs.ButtonHelper(this.Next_1, 0, 1, 2, false, new lib.btnNext(), 3);

	this.Home_1 = new lib.btnHome();
	this.Home_1.name = "Home_1";
	this.Home_1.setTransform(79.4,73.35);
	new cjs.ButtonHelper(this.Home_1, 0, 1, 2, false, new lib.btnHome(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Play_1}]}).to({state:[{t:this.Answer_1}]},9).to({state:[]},10).to({state:[{t:this.Next_1,p:{x:100.55,y:60.05}}]},10).to({state:[]},1).to({state:[{t:this.Next_1,p:{x:100.55,y:60.05}}]},19).to({state:[]},1).to({state:[{t:this.Next_1,p:{x:100.55,y:60.05}}]},8).to({state:[]},1).to({state:[{t:this.Next_1,p:{x:79.4,y:73.35}}]},10).to({state:[]},1).to({state:[{t:this.Home_1}]},19).wait(1));

	// Text
	this.instance = new lib.CachedBmp_1();
	this.instance.setTransform(316.85,15.25,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_2();
	this.instance_1.setTransform(37.2,15,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_3();
	this.instance_2.setTransform(37.2,15,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_4();
	this.instance_3.setTransform(37.2,15,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_5();
	this.instance_4.setTransform(37.2,15,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_6();
	this.instance_5.setTransform(37.2,15,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_7();
	this.instance_6.setTransform(37.2,15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_9();
	this.instance_7.setTransform(28,134.3,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_8();
	this.instance_8.setTransform(37.2,15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},9).to({state:[{t:this.instance_2}]},10).to({state:[{t:this.instance_3}]},11).to({state:[{t:this.instance_4}]},20).to({state:[{t:this.instance_5}]},9).to({state:[{t:this.instance_6}]},11).to({state:[{t:this.instance_8},{t:this.instance_7}]},19).wait(1));

	// Animation
	this.instance_9 = new lib.ManGoingWithSheep("synched",0);
	this.instance_9.setTransform(496.6,521.1);
	this.instance_9._off = true;

	this.instance_10 = new lib.ManGoingBack("synched",0);
	this.instance_10.setTransform(861.8,521.1,1,1,0,0,0,160.8,151.1);
	this.instance_10._off = true;

	this.instance_11 = new lib.ManGoingWithWolf("synched",0);
	this.instance_11.setTransform(490.6,521.1,1,1,0,0,0,166.6,151.1);
	this.instance_11._off = true;

	this.instance_12 = new lib.ManGoingBackWithSheep1("synched",0);
	this.instance_12.setTransform(765.35,513.85,1,1,0,0,0,160.8,151.1);
	this.instance_12._off = true;

	this.instance_13 = new lib.ManGoingWithHay("synched",0);
	this.instance_13.setTransform(459.6,521.1,1,1,0,0,0,175.7,151.1);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(20).to({_off:false},0).to({x:861.25},8).to({_off:true},1).wait(49).to({_off:false,x:303.4},1).to({x:847.45},9).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(30).to({_off:false},0).to({x:481.2},8).to({_off:true},1).wait(31).to({_off:false,x:835.95},0).to({x:269.25},8).to({_off:true,regX:0,regY:0,x:303.4},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(40).to({_off:false},0).to({x:856.7},8).to({_off:true},1).wait(41));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(50).to({_off:false},0).to({x:446.3},7).to({_off:true},1).wait(32));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(59).to({_off:false},0).to({x:813.4},9).to({_off:true},1).wait(21));

	// Image_1
	this.instance_14 = new lib.pngtreeyoungmancharacterpngimage_6485017();
	this.instance_14.setTransform(386,370,0.6591,0.6591);

	this.instance_15 = new lib.download7();
	this.instance_15.setTransform(0,427,0.3043,0.3043);

	this.instance_16 = new lib.clipartboatpng3();
	this.instance_16.setTransform(592.55,524,0.1082,0.1082,0,0,180);

	this.instance_17 = new lib.sheeppng26();
	this.instance_17.setTransform(154,427,0.2806,0.2806);

	this.instance_18 = new lib.cyberscootyfoinclipartxl();
	this.instance_18.setTransform(278,492,0.0785,0.0785);

	this.instance_19 = new lib.Palm_Island_PNG_Clip_Art_Image596873376();
	this.instance_19.setTransform(1324.55,200,0.0668,0.0668,0,0,180);

	this.instance_20 = new lib.Palm_Island_PNG_Clip_Art_Image596873376();
	this.instance_20.setTransform(-43,200,0.0668,0.0668);

	this.instance_21 = new lib.oceanlandscapebackgroundfreevector();
	this.instance_21.setTransform(0,1,4.0891,3.5975);

	this.instance_22 = new lib.Palm_Island_PNG_Clip_Art_Image596873376();
	this.instance_22.setTransform(0,394,0.0506,0.0506);

	this.Sheep_1 = new lib.btnSheep();
	this.Sheep_1.name = "Sheep_1";
	this.Sheep_1.setTransform(231.9,504.7,1,1,0,0,0,77.9,77.7);

	this.instance_23 = new lib.ManGoingBack("synched",0);
	this.instance_23.setTransform(861.8,521.1,1,1,0,0,0,160.8,151.1);

	this.instance_24 = new lib.wolf("synched",0);
	this.instance_24.setTransform(1092.9,510,1,1,0,0,0,70.9,90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_17},{t:this.instance_16,p:{x:592.55}},{t:this.instance_15,p:{skewY:0,x:0,y:427}},{t:this.instance_14,p:{x:386}}]}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_16,p:{x:592.55}},{t:this.instance_15,p:{skewY:0,x:0,y:427}},{t:this.instance_14,p:{x:386}},{t:this.Sheep_1,p:{x:231.9,y:504.7,skewY:0}}]},9).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_16,p:{x:592.55}},{t:this.instance_15,p:{skewY:0,x:0,y:427}},{t:this.instance_14,p:{x:420}},{t:this.Sheep_1,p:{x:425.6,y:527.15,skewY:0}}]},10).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_15,p:{skewY:0,x:0,y:427}}]},1).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_15,p:{skewY:0,x:0,y:427}},{t:this.instance_16,p:{x:957.55}},{t:this.Sheep_1,p:{x:1246.65,y:522.8,skewY:180}},{t:this.instance_14,p:{x:785}}]},9).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_15,p:{skewY:0,x:0,y:427}},{t:this.Sheep_1,p:{x:1246.65,y:522.8,skewY:180}}]},1).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_15,p:{skewY:0,x:0,y:427}},{t:this.Sheep_1,p:{x:1246.65,y:522.8,skewY:180}},{t:this.instance_16,p:{x:592.55}},{t:this.instance_14,p:{x:420}}]},9).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.Sheep_1,p:{x:1246.65,y:522.8,skewY:180}}]},1).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.Sheep_1,p:{x:1246.65,y:522.8,skewY:180}},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}},{t:this.instance_23,p:{x:861.8}}]},9).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}}]},1).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:278,y:492}},{t:this.Sheep_1,p:{x:108.2,y:511.6,skewY:0}},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}},{t:this.instance_16,p:{x:570.55}},{t:this.instance_14,p:{x:398}}]},8).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.Sheep_1,p:{x:108.2,y:511.6,skewY:0}},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}}]},1).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.Sheep_1,p:{x:108.2,y:511.6,skewY:0}},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}},{t:this.instance_18,p:{x:884,y:490}},{t:this.instance_23,p:{x:835.95}}]},10).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.Sheep_1,p:{x:108.2,y:511.6,skewY:0}},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}},{t:this.instance_18,p:{x:884,y:490}}]},1).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.Sheep_1,p:{x:108.2,y:511.6,skewY:0}},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}},{t:this.instance_18,p:{x:884,y:490}}]},8).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_15,p:{skewY:180,x:1163.8,y:420}},{t:this.instance_18,p:{x:884,y:490}}]},1).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18,p:{x:884,y:490}},{t:this.instance_23,p:{x:835.95}},{t:this.Sheep_1,p:{x:1246.65,y:522.8,skewY:180}},{t:this.instance_24}]},10).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(597,361,727.5999999999999,359.5);
// library properties:
lib.properties = {
	id: '1C4512DD81109441914C22302A3E56FE',
	width: 1280,
	height: 720,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_9.png", id:"CachedBmp_9"},
		{src:"images/CachedBmp_8.png", id:"CachedBmp_8"},
		{src:"images/CachedBmp_7.png", id:"CachedBmp_7"},
		{src:"images/CachedBmp_6.png", id:"CachedBmp_6"},
		{src:"images/CachedBmp_5.png", id:"CachedBmp_5"},
		{src:"images/CachedBmp_4.png", id:"CachedBmp_4"},
		{src:"images/CachedBmp_3.png", id:"CachedBmp_3"},
		{src:"images/CachedBmp_2.png", id:"CachedBmp_2"},
		{src:"images/clipartboatpng3.png", id:"clipartboatpng3"},
		{src:"images/Palm_Island_PNG_Clip_Art_Image596873376.png", id:"Palm_Island_PNG_Clip_Art_Image596873376"},
		{src:"images/Island_atlas_1.png", id:"Island_atlas_1"},
		{src:"images/Island_atlas_2.png", id:"Island_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['1C4512DD81109441914C22302A3E56FE'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;